SLASH_HEYTHERE1 = "/hey" ;
SLASH_HEYTHERE2 = "/ht" ;
SlashCmdList["HEYTHERE"] = function()
   if(UnitExists("target")) then
      SendChatMessage("hello" .. UnitName("target"),"SAY");
   else
      MyFunction();
   end
end
--DEFAULT_CHAT_FRAME:AddMessage("我们全是大傻逼"); 
--print(GetBillingTimeRested());

function MyFunction()
   -- body
   --print(GetActionText(1));

   --print(GetActionCooldown(1));
   -- a,b,c,d,e=GetActionCooldown(1);
   -- print(GetTime()-a);
end

function HelloWorldCommand() 
   myFrame = getglobal("HelloWorldTestFrame"); 
   if(not myFrame:IsShown()) then 
      myFrame:Show();
      print("1.打开界面。2.打印技能。3.重置技能库。");
      InitializationSkillName();
   else 
      myFrame:Hide(); 
      print("关闭界面。");
   end
end

function HelloWorldLoad() 
   getglobal("HelloWorldTestFrame"):Hide(); 
   -- DEFAULT_CHAT_FRAME:AddMessage("HelloWorld is Loaded!"); 
   SLASH_HELLOWORLD1 = "/helloworld"; 
   SLASH_HELLOWORLD2 = "/hw"; 
   SlashCmdList["HELLOWORLD"] = HelloWorldCommand;
   print("欢迎来到无脑打怪的世界");
   setTimer={};--声明一些计时器

   ----------------注册PLAYER_ENTERING_WORLD事件。因为不能初始化加载技能名称。----------------
   Init=getglobal("CoolDownMainFrame");
   Init:RegisterEvent("PLAYER_ENTERING_WORLD");
   Init:SetScript("OnEvent",function() InitializationSkillName();end);--定义事件加载函数。
   -- Init:UnregisterEvent("PLAYER_ENTERING_WORLD");--注销事件。
end 

function InitializationSkillName()
   SkNm={};
   for i=1,72 do
      local _,getSpellID=GetActionInfo(i);
      if(getSpellID~=nil)then
         local name=GetSpellInfo(getSpellID);
         if(name~=nil) then
            SkNm[name]=i;
            print(i .. name);
         else
            name=GetActionText(i);
            SkNm[name]=i;
            print(i .. name);
         end
      end
   end
end

function HelloWorldFrameUpdate() 
   text1 = getglobal("HelloWorldTestFrameSkillOneCD"); 
   text2 = getglobal("HelloWorldTestFrameTextDelay"); 
   text3 = getglobal("HelloWorldTestFrameTextMoney"); 
   -- down, up, lag = GetNetStats(); 

   local start, duration, enable = GetActionCooldown(1);
   local now=GetTime();
   ------------------------------------打印区------------------------------------
   text1:SetText("SkillOneCD "..(start==0 and 0 or (duration - now + start)));
   -- text2:SetText(SkNm["凋零缠绕"] .. ";".. SkNm["冰冷触摸"] ..";".. SkNm["符文分流"]);
   -- local _,getSpellID=GetActionInfo(11);
   -- text2:SetText(GetSpellInfo(getSpellID)~=nil and GetSpellInfo(getSpellID) or GetActionText(11));
   -- local _,s_name=GetSpecializationInfo(GetSpecialization())
   -- text3:SetText(CheckInteractDistance("target",2) and "ok" or "no");
   -- local name, rank, icon, count, debuffType, duration, expirationTime = UnitDebuff("target",1, "PLAYER");

   ------------------------------------技能CD区------------------------------------
   actionButton_CDText={};
   skill_CD={};
   for i=1,72 do
      actionButton_CDText[i]=getglobal("ActionButton" .. i .. "CooldownTextCD"); --声明框架
      
      start, duration, enable = GetActionCooldown(i);
      skill_CD[i]=(start==0 and 0 or (duration - now + start)); --计算技能CD。如果START是0则技能无CD。
   end

   -- text2:SetText(playerAuraString);
   -- 获得当前天赋的信息。
   -- local id, name_tt, description, icon, background, role = GetSpecializationInfo(GetSpecialization());
   -- textDelay:SetText(name_tt);
   --计算玩家身上的所有BUFF和DEBUFF
   --TESTING
   -- if(IsCurrentAction(64)==1) then cout=now end;
   -- textMoney:SetText(cout==nil and "no" or floor(now-cout));
   -- textDelay:SetText((GetUnitSpeed("PLAYER") / 7) * 100);--可以判断在不在移动中。
   -- textMoney:SetText(GetUnitPitch("PLAYER")/7*100);
   -- textMoney:SetText(StringFindAnd("abcdefg","aaa","bbb") and "true" or "false");
   -- textDelay:SetText(n_RuneIsCD);
   -- local pet= UnitHealth("PLAYERPET");

   local _, Specialization = GetSpecializationInfo(GetSpecialization());--获得玩家专精。
   local debuffString=TargetDebuff(Specialization);
   local playerAuraString=PlayerAura(Specialization);
   local n_RuneIsCD=N_RuneIsCD();
   local playerHealth=UnitHealth("PLAYER")/UnitHealthMax("PLAYER");
   local ttIsPlayer=UnitIsUnit("targettarget", "player");
   -- text3:SetText(setTimer["天灾契约"]);

   for i=1,72 do  --这块主要负责技能刷颜色。
      actionButton_CDText[i]:SetTextColor(0,1,0);--先把所有技能刷成绿的。再看哪些要刷红。

      AutoActionBar(i,Specialization,playerAuraString,debuffString,n_RuneIsCD,setTimer,playerHealth,ttIsPlayer,now)

      local isUsable, notEnoughMana = IsUsableAction(i);
      if(IsActionInRange(i,"target")==0 or skill_CD[i]>0.5 or isUsable==nil or notEnoughMana==1) then 
         actionButton_CDText[i]:SetTextColor(1,0,0)
      end   --如果在技能范围之外则刷红。--如果技能CD刷红。--如果不可用刷红。--如果没有魔法刷红。
   end
      
   if(IsCurrentAction(SkNm["传染"])==1) then setTimer["传染"]=now end;--如果用了传染，则记录时间。注：已在HelloWorldLoad声明setTimer={}计时器。
   if(IsCurrentAction(SkNm["亡者复生"])==1) then setTimer["天灾契约"]=now end;--如果用了亡者复生，则记录时间。注：已在HelloWorldLoad声明setTimer={}计时器。
   if(IsCurrentAction(SkNm["天灾契约"]  )==1) then setTimer["天灾契约"]=nil end;--如果用了天灾契约，则消灭计时器。注：已在HelloWorldLoad声明setTimer={}计时器。
   -- textMoney:SetText(setTimer["传染"]==nil and "no" or floor(now-setTimer["传染"])); 
   --冰霜疫病；血之疫病。
   -- Testing();
end

function StringFindOr(stringSearched,...)
   local arg={...};
   local result=false;
   for i,v in ipairs(arg) do
      result=result or string.find(stringSearched,v)~=nil
   end
   return result
end

function StringFindAnd(stringSearched,...)
   local arg={...};
   local result=true;
   for i,v in ipairs(arg) do
      result=result and string.find(stringSearched,v)~=nil
   end
   return result
end

-- function HelloWorldEvent()
--    -- getglobal("CoolDownMainFrame"):SetScript("PLAYER_ENTERING_WORLD", print("钱老师加载了事件模块"));
--    -- getglobal("CoolDownMainFrame"):SetScript("PLAYER_ENTERING_WORLD", InitializationSkillName());
--    -- getglobal("CoolDownMainFrame"):SetScript("OnEvent",InitializationSkillName());
--    -- getglobal("CoolDownMainFrame"):UnregisterEvent("PLAYER_ENTERING_WORLD");
--    Init:SetScript("OnEvent",Init.);
--    Init:UnregisterEvent("PLAYER_ENTERING_WORLD");
-- end

function TargetDebuff(Specialization)
   local TargetDebuffList={"冰霜疫病","血之疫病","寒冰锁链","冻疮","物理易伤"};
   local targetDebuffString="";  --初始返回值targetDebuffString为空。

   for i=1,40 do
      local name, _, _, count, debuffType, duration, expirationTime = UnitDebuff("target",i,"PLAYER");
      if(name==nil)then break end;

      for i,v in ipairs(TargetDebuffList) do --遍历所有TargetDebuff列表
         if name==v then targetDebuffString=targetDebuffString..name end; --如果发现Aura存在于之前定义的列表中，则保存在临时变量中。
      end
   end

   return targetDebuffString
end

function PlayerAura(Specialization)
   local playerAuraList={"冰霜灵气","鲜血灵气","邪恶灵气","杀戮机器","符能转换","冰霜之柱","鲜血充能","冰冻之雾","巫妖之躯","瘫痪","白骨之盾"};
   local playerAuraString=""; --初始返回值playerAuraString为空。

   for i=1,40 do
      local name, _, _, count, debuffType, duration, expirationTime = UnitAura("PLAYER",i);
      if(name==nil)then break end;

      for i,v in ipairs(playerAuraList) do --遍历所有Aura
         if name==v then playerAuraString=playerAuraString..name end; --如果发现Aura存在于之前定义的列表中，则保存在临时变量中。
      end
   end

   return playerAuraString
end

function N_RuneIsCD()
   local n_RuneIsCD=0;  --计算冷却中符文的数量。!!!最奇葩的一点；ID和符文位置的对应关系是1,2,5,6,3,4。
   for i=1,6 do
      _, _, runeReady = GetRuneCooldown(i)
      if not runeReady then n_RuneIsCD=n_RuneIsCD+1 end;
   end
   return n_RuneIsCD
end

function AutoActionBar(i,Specialization,playerAuraString,debuffString,n_RuneIsCD,setTimer,playerHealth,ttIsPlayer,now)
   local targetIsChansting=TargetIsChansting();
   if(Specialization=="冰霜") then

      ActBtnTurnRed(i,1,StringFindOr(playerAuraString,"杀戮机器") and n_RuneIsCD<2);--该技能被凛风冲击完全覆盖，因此作用就是杀戮机器BUFF出来后湮没不能用的情况下用用。
      ActBtnTurnRed(i,2,not StringFindOr(debuffString,"血之疫病")); --技能2如果检测到血之疫病则刷红技能2CD。
      ActBtnTurnRed(i,12,StringFindAnd(debuffString,"血之疫病","冰霜疫病") and n_RuneIsCD>=2);--吸血瘟疫。目标身上有2个疾病，且自身有2个符文处于CD。
      ActBtnTurnRed(i,70,GetActionCount(70)>=5 and n_RuneIsCD>=1);--活力分流。5个充能，且至少有一枚符文在CD。
      ActBtnTurnRed(i,62,n_RuneIsCD>=6 and UnitPower("PLAYER")<75);--符文武器增效。6个符文CD且能量小于75。
      ActBtnTurnRed(i,6,targetIsChansting);--心灵冰冻。对方在吟唱法术。后续改进建议：对于PVP玩家，吟唱可以还没念到一半的时候打断。施法要念到一半后打断。
      ActBtnTurnRed(i,72,targetIsChansting);--绞袭。对方在吟唱法术。
      ActBtnTurnRed(i,66,targetIsChansting and ttIsPlayer);--反魔法护罩。对方在对本玩家唱法术。
      ActBtnTurnRed(i,5,not StringFindOr(debuffString,"寒冰锁链","冻疮") and UnitIsPlayer("target"));--冰冻锁链。目标无减速，目标非玩家。
      ActBtnTurnRed(i,61,setTimer["传染"]~=nil and (now-setTimer["传染"])<30);--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnRed(i,64,(setTimer["传染"]==nil or (now-setTimer["传染"])>=30) and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--传染。放过30秒内就不要再放了。
      ActBtnTurnRed(i,3,not StringFindOr(debuffString,"冰冻之雾") or n_RuneIsCD==0);--冰霜打击。出冰冻之雾的时候给凛风冲击让路；没有符文的时候就不要让了。
      ActBtnTurnRed(i,4,not StringFindOr(debuffString,"冰霜疫病") or StringFindOr(playerAuraString,"冰冻之雾"));--没有冰霜疫病或免费冰冻之雾的时候用凛风打击。
      ActBtnTurnRed(i,11,false); --灵界打击先不用。以后留着给雕文。
      ActBtnTurnRed(i,10,false); --凋零缠绕先不用。以后留着给雕文。
      ActBtnTurnRed(i,9,StringFindOr(debuffString,"物理易伤") and StringFindOr(playerAuraString,"杀戮机器") and IsActionInRange(8,"target")==1); --冰霜之柱。湮灭可用+易伤+杀戮机器
      ActBtnTurnRed(i,71,StringFindOr(playerAuraString,"符能转换") and playerHealth>=0.9 or not StringFindOr(playerAuraString,"符能转换") and playerHealth<0.9); --符能转换。
      ActBtnTurnRed(i,65,playerHealth<0.6); --冰封之韧。

   elseif(Specialization=="鲜血") then--鲜血天赋。

      -----------------------AOE技能先刷成紫色，地图炮刷成蓝色-----------------------
      ActBtnTurnPink(i,SkNm["血液沸腾"]);--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnPink(i,SkNm["传染"]);--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnBlue(i,SkNm["枯萎凋零"]); --枯萎凋零

      -----------------------根据情况决定刷成啥颜色-----------------------      
      ActBtnTurnRed(i,SkNm["冰冷触摸"],not StringFindOr(debuffString,"冰霜疫病"));--冰冷触摸。如果无冰霜疫病则触发。
      ActBtnTurnRed(i,SkNm["暗影打击"],not StringFindOr(debuffString,"血之疫病"));--技能2如果检测到血之疫病则刷红技能2CD。
      ActBtnTurnRed(i,SkNm["吸血瘟疫"],StringFindAnd(debuffString,"血之疫病","冰霜疫病") and n_RuneIsCD>=2);--吸血瘟疫。目标身上有2个疾病，且自身有2个符文处于CD。
      ActBtnTurnRed(i,SkNm["活力分流"],GetActionCount(70)>=5 and n_RuneIsCD>=1);--活力分流。5个充能，且至少有一枚符文在CD。
      ActBtnTurnRed(i,SkNm["符文武器增效"],n_RuneIsCD>=6 and UnitPower("PLAYER")<75);--符文武器增效。6个符文CD且能量小于75。
      ActBtnTurnRed(i,SkNm["心灵冰冻"],targetIsChansting);--心灵冰冻。对方在吟唱法术。后续改进建议：对于PVP玩家，吟唱可以还没念到一半的时候打断。施法要念到一半后打断。
      ActBtnTurnRed(i,SkNm["绞袭"],targetIsChansting);--绞袭。对方在吟唱法术。
      ActBtnTurnRed(i,SkNm["反魔法护罩"],targetIsChansting and ttIsPlayer);--反魔法护罩。对方在对本玩家唱法术。
      ActBtnTurnRed(i,SkNm["寒冰锁链"],not StringFindOr(debuffString,"寒冰锁链","冻疮") and UnitIsPlayer("target"));--冰冻锁链。目标无减速，目标非玩家。
      ActBtnTurnRed(i,SkNm["血液沸腾"],setTimer["传染"]~=nil and (now-setTimer["传染"])<30 and StringFindOr(debuffString,"血之疫病","冰霜疫病"));--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnRed(i,SkNm["传染"],(setTimer["传染"]==nil or (now-setTimer["传染"])>=30) and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--传染。放过30秒内就不要再放了。
      ActBtnTurnRed(i,SkNm["符文打击"],not StringFindOr(playerAuraString,"巫妖之躯") or playerHealth>0.85);--符文打击。血少让路给变身吃大便。
      ActBtnTurnRed(i,SkNm["心脏打击"],UnitPower("PLAYER")<80 and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--心脏打击。无限制。
      ActBtnTurnRed(i,SkNm["灵界打击"],UnitPower("PLAYER")<70); --灵界打击=。积攒了5个点。
      ActBtnTurnRed(i,SkNm["凋零缠绕"],StringFindOr(playerAuraString,"巫妖之躯")); --凋零缠绕先不用。
      ActBtnTurnRed(i,SkNm["冰封之韧"],playerHealth<0.7); --冰封之韧。
      ActBtnTurnRed(i,SkNm["符文分流"],playerHealth<0.85); --符文分流。
      ActBtnTurnRed(i,SkNm["亡者复生"],playerHealth<0.5); --亡者复生。
      ActBtnTurnRed(i,SkNm["黑暗命令"],not ttIsPlayer); --黑暗命令。
      ActBtnTurnRed(i,SkNm["天灾契约"],setTimer["天灾契约"]~=nil and (now-setTimer["天灾契约"])<45 and playerHealth<0.6); --天灾契约。亡者复生45秒内吃。
      ActBtnTurnRed(i,SkNm["巫妖之躯"],playerHealth<0.6); --巫妖之躯。
      ActBtnTurnRed(i,SkNm["符文刃舞"],playerHealth<0.75); --符文刃舞。
      ActBtnTurnRed(i,SkNm["死亡之握"],not CheckInteractDistance("target",1) or not CheckInteractDistance("target",2) and (targetIsChansting or not ttIsPlayer)); --死亡之握。
      ActBtnTurnRed(i,SkNm["吸血鬼之血"],playerHealth<0.4); --吸血鬼之血
      ActBtnTurnRed(i,SkNm["饰品1"],playerHealth<0.2); --饰品1
      ActBtnTurnRed(i,SkNm["自利"],StringFindOr(playerAuraString,"瘫痪","变形")); --自利。
      ActBtnTurnRed(i,SkNm["白骨之盾"],not StringFindOr(playerAuraString,"白骨之盾")); --白骨之盾。

   end
end 

function ActBtnTurnRed(i,j,condition)
   if(i==j and not condition) then actionButton_CDText[j]:SetTextColor(1,0,0) end;
end

function ActBtnTurnBlue(i,j)
   if(i==j) then actionButton_CDText[j]:SetTextColor(0,0,1) end;
end

function ActBtnTurnPink(i,j)
   if(i==j) then actionButton_CDText[j]:SetTextColor(1,0,1) end;
end

function TargetIsChansting()
   local spellName_Casting= UnitCastingInfo("target");
   local spellName_Channel= UnitChannelInfo("target");
   return spellName_Channel~=nil or spellName_Casting~=nil
end