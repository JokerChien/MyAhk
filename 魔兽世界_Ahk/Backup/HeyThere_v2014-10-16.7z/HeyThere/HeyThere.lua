SLASH_HEYTHERE1 = "/hey" ;
SLASH_HEYTHERE2 = "/ht" ;
SlashCmdList["HEYTHERE"] = function()
   if(UnitExists("target")) then
      SendChatMessage("hello" .. UnitName("target"),"SAY");
   else
      MyFunction();
   end
end
--DEFAULT_CHAT_FRAME:AddMessage("我们全是大傻逼"); 
--print(GetBillingTimeRested());

function MyFunction()
   -- body
   --print(GetActionText(1));

   --print(GetActionCooldown(1));
   -- a,b,c,d,e=GetActionCooldown(1);
   -- print(GetTime()-a);
end

function HelloWorldCommand() 
   myFrame = getglobal("HelloWorldTestFrame"); 
   if(not myFrame:IsShown()) then 
      myFrame:Show();
      print("1.打开界面。2.打印技能。3.重置技能库。");
      InitializationSkillName();
   else 
      myFrame:Hide(); 
      print("关闭界面。");
   end
end

function HelloWorldLoad() 
   getglobal("HelloWorldTestFrame"):Hide(); 
   -- DEFAULT_CHAT_FRAME:AddMessage("HelloWorld is Loaded!"); 
   SLASH_HELLOWORLD1 = "/helloworld"; 
   SLASH_HELLOWORLD2 = "/hw"; 
   SlashCmdList["HELLOWORLD"] = HelloWorldCommand;
   print("欢迎来到无脑打怪的世界");
   setTimer={};--声明一些计时器
   attackMode=0;--申明攻击模式为0;1为单体攻击;2为AOE。
   Test_Skill="冰霜之路";

   ----------------注册PLAYER_ENTERING_WORLD事件。因为不能初始化加载技能名称。----------------
   Init=getglobal("CoolDownMainFrame");
   Init:RegisterEvent("PLAYER_ENTERING_WORLD");
   Init:SetScript("OnEvent",function() InitializationSkillName();end);--定义事件加载函数。
   -- Init:UnregisterEvent("PLAYER_ENTERING_WORLD");--注销事件。
end 

function InitializationSkillName()
   SkNm={};
   for i=1,72 do
      local _,getSpellID=GetActionInfo(i);
      if(getSpellID~=nil)then
         local name=GetSpellInfo(getSpellID);
         if(name~=nil) then
            SkNm[name]=i;
            print(i .. name);
         else
            name=GetActionText(i);
            SkNm[name]=i;
            print(i .. name);
         end
      end
   end
end

function HelloWorldFrameUpdate() 
   text1 = getglobal("HelloWorldTestFrameSkillOneCD"); 
   text2 = getglobal("HelloWorldTestFrameTextDelay"); 
   text3 = getglobal("HelloWorldTestFrameTextMoney"); 
   -- down, up, lag = GetNetStats(); 

   local start, duration, enable = GetActionCooldown(1);
   local now=GetTime();
   ------------------------------------打印区------------------------------------
   text1:SetText("SkillOneCD "..(start==0 and 0 or (duration - now + start)));
   -- text2:SetText(UnitCanAttack("player","target") and "Yessss" or "Nooooooo");
   -- text2:SetText(SkNm["凋零缠绕"] .. ";".. SkNm["冰冷触摸"] ..";".. SkNm["符文分流"]);
   -- local _,getSpellID=GetActionInfo(11);
   -- text2:SetText(GetSpellInfo(getSpellID)~=nil and GetSpellInfo(getSpellID) or GetActionText(11));
   -- local _,s_name=GetspecializationInfo(Getspecialization())
   -- text3:SetText(CheckInteractDistance("target",2) and "ok" or "no");
   -- local name, rank, icon, count, debuffType, duration, expirationTime = UnitDebuff("target",1, "PLAYER");

   ------------------------------------技能CD区------------------------------------
   actionButton_CDText={};
   skill_CD={};
   for i=1,72 do
      actionButton_CDText[i]=getglobal("ActionButton" .. i .. "CooldownTextCD"); --声明框架
      
      start, duration, enable = GetActionCooldown(i);
      skill_CD[i]=(start==0 and 0 or (duration - now + start)); --计算技能CD。如果START是0则技能无CD。
   end

   -- text2:SetText(GetUnitPitch("player"));
   -- text3:SetText(GetUnitPitch("target"));
   -- text2:SetText(playerAuraString);
   -- 获得当前天赋的信息。
   -- local id, name_tt, description, icon, background, role = GetspecializationInfo(Getspecialization());
   -- textDelay:SetText(name_tt);
   --计算玩家身上的所有BUFF和DEBUFF
   --TESTING
   -- if(IsCurrentAction(64)==1) then cout=now end;
   -- textMoney:SetText(cout==nil and "no" or floor(now-cout));
   -- textDelay:SetText((GetUnitSpeed("PLAYER") / 7) * 100);--可以判断在不在移动中。
   -- textMoney:SetText(GetUnitPitch("PLAYER")/7*100);
   -- textMoney:SetText(StringFindAnd("abcdefg","aaa","bbb") and "true" or "false");
   -- textDelay:SetText(n_RuneIsCD);
   -- local pet= UnitHealth("PLAYERPET");

   local _, specialization = GetSpecializationInfo(GetSpecialization());--获得玩家专精。
   local name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId = UnitAura("target", 1,"HARMFUL");
   -- text2:SetText(UnitCleaning(specialization,"target","HARMFUL"));
   local debuffString=TargetDebuff(specialization);
   local playerAuraString=PlayerAura(specialization);
   local n_RuneIsCD=N_RuneIsCD();
   local playerHealth=UnitHealth("PLAYER")/UnitHealthMax("PLAYER");
   local ttIsPlayer=UnitIsUnit("targettarget", "player");
   local imChansting=WhoIsChansting("player");
   
   -- if(attackMode==1) then 
   --    text2:SetText("单体攻击");
   -- elseif(attackMode==2) then 
   --    text2:SetText("群体攻击"); 
   -- end;
   -- text3:SetText(setTimer["天灾契约"]);

   for i=1,72 do  --这块主要负责技能刷颜色。
      actionButton_CDText[i]:SetTextColor(0,1,0);--先把所有技能刷成绿的。再看哪些要刷红。

      AutoActionBar(i,specialization,playerAuraString,debuffString,n_RuneIsCD,setTimer,playerHealth,ttIsPlayer,now)

      local isUsable, notEnoughMana = IsUsableAction(i);
      if(IsActionInRange(i,"target")==0 or imChansting and skill_CD[i]>0 or not imChansting and skill_CD[i]>0.5 or isUsable==nil or notEnoughMana==1 or imChansting and i~=SkNm["目标"]) then 
         actionButton_CDText[i]:SetTextColor(1,0,0)
      end   --如果在技能范围之外则刷红。--如果技能CD刷红。--如果不可用刷红。--如果没有魔法刷红。--如果我在读施法条但不包括目标。
   end
   
   PaintPartyButton(SkNm["队伍"]);

   if(specialization=="冰霜" or specialization=="鲜血") then    --死亡骑士的内置计时器。
      if(IsCurrentAction(SkNm["传染"])==1) then setTimer["传染"]=now end;--如果用了传染，则记录时间。注：已在HelloWorldLoad声明setTimer={}计时器。
      if(IsCurrentAction(SkNm["亡者复生"])==1) then setTimer["天灾契约"]=now end;--如果用了亡者复生，则记录时间。注：已在HelloWorldLoad声明setTimer={}计时器。
      if(IsCurrentAction(SkNm["天灾契约"]  )==1) then setTimer["天灾契约"]=nil end;--如果用了天灾契约，则消灭计时器。注：已在HelloWorldLoad声明setTimer={}计时器。
   elseif(specialization=="戒律")then
      if(IsCurrentAction(SkNm["愈合祷言"])==1) then setTimer["愈合祷言"]=now end;--如果用了愈合祷言，则记录时间。注：已在HelloWorldLoad声明setTimer={}计时器。
   end

   -- if(IsCurrentAction(SkNm["开锁"])==1) then
   --    text2:SetText("单体攻击");
   -- elseif(IsCurrentAction(SkNm["队伍"])==1) then
   --    text2:SetText("群体攻击");
   -- end
end

function StringFindOr(stringSearched,...)
   local arg={...};
   local result=false;
   for i,v in ipairs(arg) do
      result=result or string.find(stringSearched,v)~=nil
   end
   return result
end

function StringFindAnd(stringSearched,...)
   local arg={...};
   local result=true;
   for i,v in ipairs(arg) do
      result=result and string.find(stringSearched,v)~=nil
   end
   return result
end

-- function HelloWorldEvent()
--    -- getglobal("CoolDownMainFrame"):SetScript("PLAYER_ENTERING_WORLD", print("钱老师加载了事件模块"));
--    -- getglobal("CoolDownMainFrame"):SetScript("PLAYER_ENTERING_WORLD", InitializationSkillName());
--    -- getglobal("CoolDownMainFrame"):SetScript("OnEvent",InitializationSkillName());
--    -- getglobal("CoolDownMainFrame"):UnregisterEvent("PLAYER_ENTERING_WORLD");
--    Init:SetScript("OnEvent",Init.);
--    Init:UnregisterEvent("PLAYER_ENTERING_WORLD");
-- end

function TargetDebuff(specialization)
   local TargetDebuffList={};
   if(specialization=="冰霜" or specialization=="鲜血") then
      TargetDebuffList={"冰霜疫病","血之疫病","寒冰锁链","冻疮","物理易伤"};
   elseif(specialization=="战斗") then
      TargetDebuffList={"要害打击"};
   elseif(specialization=="野兽控制") then
      TargetDebuffList={"要害打击"};
   else
      TargetDebuffList={"暗言术：痛"};
   end
   
   local targetDebuffString="";  --初始返回值targetDebuffString为空。

   for i=1,40 do
      local name, _, _, count, debuffType, duration, expirationTime = UnitDebuff("target",i,"PLAYER");
      if(name==nil)then break end;

      for i,v in ipairs(TargetDebuffList) do --遍历所有TargetDebuff列表
         if name==v then targetDebuffString=targetDebuffString..name end; --如果发现Aura存在于之前定义的列表中，则保存在临时变量中。
      end
   end

   return targetDebuffString
end

function Unit_Aura(specialization,unit,filter)--注意，这个FILTER单单PLAYER是不行的。
   local unitAuraList={};    --声明UnitAura清单为空。
   local unitAuraString="";  --初始返回值targetDebuffString为空。

   if(specialization=="戒律" and unit=="target" and filter=="HELPFUL") then --注：玩家戒律牧对目标施放的BUFF。
      unitAuraList={"恢复","愈合祷言","真言术：韧"};
   end
   
   for i=1,40 do
      local name, _, _, count, auraType, duration, expirationTime = UnitAura(unit,i,filter);
      if(name==nil)then break end;
      
      for i,v in ipairs(unitAuraList) do --遍历所有TargetDebuff列表
         if(string.find(name,v)~=nil) then unitAuraString=unitAuraString..name end; --如果发现Aura存在于之前定义的列表中，则保存在临时变量中。
      end
   end

   return unitAuraString
end

function PlayerAura(specialization)
   local playerAuraList={};
   local playerAuraString=""; --初始返回值playerAuraString为空。

   if(specialization=="鲜血" or specialization=="冰霜") then
      playerAuraList={"冰霜灵气","鲜血灵气","邪恶灵气","杀戮机器","符能转换","冰霜之柱","鲜血充能","冰冻之雾","巫妖之躯","白骨之盾","瘫痪","变形","昏迷"};
   elseif(specialization=="战斗") then
      playerAuraList={"切割","剑刃乱舞","复原"};
   elseif(specialization=="野兽控制") then
      playerAuraList={};
   else
      playerAuraList={"心灵之火","光明涌动","心灵意志","瘫痪","变形","昏迷","恐惧"};
   end
   
   for i=1,40 do
      local name, _, _, count, debuffType, duration, expirationTime = UnitAura("PLAYER",i);
      if(name==nil)then break end;

      for i,v in ipairs(playerAuraList) do --遍历所有Aura
         if name==v then playerAuraString=playerAuraString..name end; --如果发现Aura存在于之前定义的列表中，则保存在临时变量中。
      end
   end

   return playerAuraString
end

function N_RuneIsCD()
   local n_RuneIsCD=0;  --计算冷却中符文的数量。!!!最奇葩的一点；ID和符文位置的对应关系是1,2,5,6,3,4。
   for i=1,6 do
      _, _, runeReady = GetRuneCooldown(i)
      if not runeReady then n_RuneIsCD=n_RuneIsCD+1 end;
   end
   return n_RuneIsCD
end

function AutoActionBar(i,specialization,playerAuraString,debuffString,n_RuneIsCD,setTimer,playerHealth,ttIsPlayer,now)
   local targetIsChansting=WhoIsChansting("target");
   if(specialization=="冰霜") then

      ActBtnTurnRed(i,1,StringFindOr(playerAuraString,"杀戮机器") and n_RuneIsCD<2);--该技能被凛风冲击完全覆盖，因此作用就是杀戮机器BUFF出来后湮没不能用的情况下用用。
      ActBtnTurnRed(i,2,not StringFindOr(debuffString,"血之疫病")); --技能2如果检测到血之疫病则刷红技能2CD。
      ActBtnTurnRed(i,12,StringFindAnd(debuffString,"血之疫病","冰霜疫病") and n_RuneIsCD>=2);--吸血瘟疫。目标身上有2个疾病，且自身有2个符文处于CD。
      ActBtnTurnRed(i,70,GetActionCount(70)>=5 and n_RuneIsCD>=1);--活力分流。5个充能，且至少有一枚符文在CD。
      ActBtnTurnRed(i,62,n_RuneIsCD>=6 and UnitPower("PLAYER")<75);--符文武器增效。6个符文CD且能量小于75。
      ActBtnTurnRed(i,6,targetIsChansting);--心灵冰冻。对方在吟唱法术。后续改进建议：对于PVP玩家，吟唱可以还没念到一半的时候打断。施法要念到一半后打断。
      ActBtnTurnRed(i,72,targetIsChansting);--绞袭。对方在吟唱法术。
      ActBtnTurnRed(i,66,targetIsChansting and ttIsPlayer);--反魔法护罩。对方在对本玩家唱法术。
      ActBtnTurnRed(i,5,not StringFindOr(debuffString,"寒冰锁链","冻疮") and UnitIsPlayer("target"));--冰冻锁链。目标无减速，目标非玩家。
      ActBtnTurnRed(i,61,setTimer["传染"]~=nil and (now-setTimer["传染"])<30);--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnRed(i,64,(setTimer["传染"]==nil or (now-setTimer["传染"])>=30) and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--传染。放过30秒内就不要再放了。
      ActBtnTurnRed(i,3,not StringFindOr(debuffString,"冰冻之雾") or n_RuneIsCD==0);--冰霜打击。出冰冻之雾的时候给凛风冲击让路；没有符文的时候就不要让了。
      ActBtnTurnRed(i,4,not StringFindOr(debuffString,"冰霜疫病") or StringFindOr(playerAuraString,"冰冻之雾"));--没有冰霜疫病或免费冰冻之雾的时候用凛风打击。
      ActBtnTurnRed(i,11,false); --灵界打击先不用。以后留着给雕文。
      ActBtnTurnRed(i,10,false); --凋零缠绕先不用。以后留着给雕文。
      ActBtnTurnRed(i,9,StringFindOr(debuffString,"物理易伤") and StringFindOr(playerAuraString,"杀戮机器") and IsActionInRange(8,"target")==1); --冰霜之柱。湮灭可用+易伤+杀戮机器
      ActBtnTurnRed(i,71,StringFindOr(playerAuraString,"符能转换") and playerHealth>=0.9 or not StringFindOr(playerAuraString,"符能转换") and playerHealth<0.9); --符能转换。
      ActBtnTurnRed(i,65,playerHealth<0.6); --冰封之韧。

   elseif(specialization=="鲜血") then--鲜血天赋。

      -----------------------AOE技能先刷成紫色，地图炮刷成蓝色-----------------------
      ActBtnTurnPink(i,SkNm["血液沸腾"]);--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnPink(i,SkNm["传染"]);--传染。
      ActBtnTurnBlue(i,SkNm["枯萎凋零"]); --枯萎凋零。

      -----------------------根据情况决定刷成啥颜色-----------------------      
      ActBtnTurnRed(i,SkNm["冰冷触摸"],not StringFindOr(debuffString,"冰霜疫病"));--冰冷触摸。如果无冰霜疫病则触发。
      ActBtnTurnRed(i,SkNm["暗影打击"],not StringFindOr(debuffString,"血之疫病"));--技能2如果检测到血之疫病则刷红技能2CD。
      ActBtnTurnRed(i,SkNm["吸血瘟疫"],StringFindAnd(debuffString,"血之疫病","冰霜疫病") and n_RuneIsCD>=2);--吸血瘟疫。目标身上有2个疾病，且自身有2个符文处于CD。
      ActBtnTurnRed(i,SkNm["活力分流"],GetActionCount(70)>=5 and n_RuneIsCD>=1);--活力分流。5个充能，且至少有一枚符文在CD。
      ActBtnTurnRed(i,SkNm["符文武器增效"],n_RuneIsCD>=6 and UnitPower("PLAYER")<75);--符文武器增效。6个符文CD且能量小于75。
      ActBtnTurnRed(i,SkNm["心灵冰冻"],targetIsChansting);--心灵冰冻。对方在吟唱法术。后续改进建议：对于PVP玩家，吟唱可以还没念到一半的时候打断。施法要念到一半后打断。
      ActBtnTurnRed(i,SkNm["绞袭"],targetIsChansting);--绞袭。对方在吟唱法术。
      ActBtnTurnRed(i,SkNm["反魔法护罩"],targetIsChansting and ttIsPlayer);--反魔法护罩。对方在对本玩家唱法术。
      ActBtnTurnRed(i,SkNm["寒冰锁链"],not StringFindOr(debuffString,"寒冰锁链","冻疮") and UnitIsPlayer("target"));--冰冻锁链。目标无减速，目标非玩家。
      ActBtnTurnRed(i,SkNm["血液沸腾"],StringFindAnd(debuffString,"血之疫病","冰霜疫病") and setTimer["传染"]~=nil and (now-setTimer["传染"])<30 and StringFindOr(debuffString,"血之疫病","冰霜疫病"));--血液沸腾。一定要在感染放完的30秒内放这招。
      ActBtnTurnRed(i,SkNm["传染"],(setTimer["传染"]==nil or (now-setTimer["传染"])>=30) and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--传染。放过30秒内就不要再放了。
      ActBtnTurnRed(i,SkNm["符文打击"],not StringFindOr(playerAuraString,"巫妖之躯") or playerHealth>0.85);--符文打击。血少让路给变身吃大便。
      ActBtnTurnRed(i,SkNm["心脏打击"],UnitPower("PLAYER")<80 and StringFindAnd(debuffString,"血之疫病","冰霜疫病"));--心脏打击。无限制。
      ActBtnTurnRed(i,SkNm["灵界打击"],UnitPower("PLAYER")<70); --灵界打击=。积攒了5个点。
      ActBtnTurnRed(i,SkNm["凋零缠绕"],StringFindOr(playerAuraString,"巫妖之躯")); --凋零缠绕先不用。
      ActBtnTurnRed(i,SkNm["冰封之韧"],playerHealth<0.7); --冰封之韧。
      ActBtnTurnRed(i,SkNm["符文分流"],playerHealth<0.85); --符文分流。
      ActBtnTurnRed(i,SkNm["亡者复生"],playerHealth<0.5); --亡者复生。
      ActBtnTurnRed(i,SkNm["黑暗命令"],not ttIsPlayer); --黑暗命令。
      ActBtnTurnRed(i,SkNm["天灾契约"],setTimer["天灾契约"]~=nil and (now-setTimer["天灾契约"])<45 and playerHealth<0.6); --天灾契约。亡者复生45秒内吃。
      ActBtnTurnRed(i,SkNm["巫妖之躯"],playerHealth<0.6); --巫妖之躯。
      ActBtnTurnRed(i,SkNm["符文刃舞"],playerHealth<0.75); --符文刃舞。
      ActBtnTurnRed(i,SkNm["死亡之握"],not CheckInteractDistance("target",1) or not CheckInteractDistance("target",2) and (targetIsChansting or not ttIsPlayer)); --死亡之握。
      ActBtnTurnRed(i,SkNm["吸血鬼之血"],playerHealth<0.4); --吸血鬼之血
      ActBtnTurnRed(i,SkNm["饰品1"],playerHealth<0.2); --饰品1
      ActBtnTurnRed(i,SkNm["自利"],not HasFullControl()); --自利。
      ActBtnTurnRed(i,SkNm["白骨之盾"],not StringFindOr(playerAuraString,"白骨之盾")); --白骨之盾。

   elseif(specialization=="戒律") then--牧师戒律天赋。
      -- local imChansting=WhoIsChansting("player");
      local imMoving=GetUnitSpeed("player")>0;
      local isEnemy=UnitCanAttack("player","target");
      local the2not = not imMoving and not isEnemy
      local targetHealth=UnitHealth("target")/UnitHealthMax("target");
      local playerMana=UnitPower("player",0)/UnitPowerMax("player",0);--SPELL_POWER_MANA = 0 SPELL_POWER_RAGE = 1 SPELL_POWER_ENERGY = 3 
      local targetBuff=Unit_Aura(specialization,"target","HELPFUL");
      local threatStatus = UnitThreatSituation("target");
      local plrThrStatus = UnitThreatSituation("player");
      local targetIsTanking = threatStatus~=nil and threatStatus>1
      local playerIsTanking = plrThrStatus~=nil and plrThrStatus>1
      local debuffCleaning = UnitCleaning(specialization,"target","HARMFUL");

      ActBtnTurnRed(i,SkNm["苦修"],the2not and targetHealth<0.55);--苦修。
      ActBtnTurnRed(i,SkNm["真言术：盾"],not isEnemy and targetIsTanking and targetHealth<1);--真言术：盾。
      ActBtnTurnRed(i,SkNm["恢复"],not isEnemy and not StringFindOr(targetBuff,"恢复") and targetHealth<0.95);--恢复。
      ActBtnTurnRed(i,SkNm["愈合祷言"],not isEnemy and not StringFindOr(targetBuff,"愈合祷言") and targetHealth<0.75 and targetIsTanking and setTimer["愈合祷言"]~=nil and (now-setTimer["愈合祷言"])<35);--愈合祷言
      ActBtnTurnRed(i,SkNm["希望圣歌"],not imMoving and playerMana<0.3);--希望圣歌。
      ActBtnTurnRed(i,SkNm["治疗祷言"],false);--治疗祷言
      ActBtnTurnRed(i,SkNm["快速治疗"],not isEnemy and (not imMoving or StringFindOr(playerAuraString,"光明涌动")) and targetHealth<0.75);--快速治疗。光明涌动会瞬发。
      ActBtnTurnRed(i,SkNm["联结治疗"],the2not and targetHealth<0.75 and playerHealth<0.75 and not UnitIsUnit("target","player"));--联结治疗。
      ActBtnTurnRed(i,SkNm["强效治疗术"],the2not and targetHealth<0.55);--强效治疗术。
      ActBtnTurnRed(i,SkNm["纯净术"],not isEnemy and StringFindOr(debuffCleaning,"Magic","Disease"));--纯净术。
      ActBtnTurnRed(i,SkNm["暗言术：痛"],isEnemy and not StringFindOr(debuffString,"暗言术：痛"));--暗言术：痛。
      -- ActBtnTurnRed(i,SkNm["神圣之火"],true);--神圣之火。
      ActBtnTurnRed(i,SkNm["灵魂护壳"],false);--灵魂护壳

      ActBtnTurnRed(i,SkNm["痛苦压制"],not isEnemy and targetHealth<0.55 and targetIsTanking);--痛苦压制
      ActBtnTurnRed(i,SkNm["真言术：障"],false);--真言术：障
      ActBtnTurnRed(i,SkNm["心灵尖啸"],false);--心灵尖啸
      ActBtnTurnRed(i,SkNm["暗影"],playerMana<0.55);--暗影魔。目标是不是ENEMY由宏控制。有个BUG，只能把暗影魔叫成暗影。
      ActBtnTurnRed(i,SkNm["心灵专注"],targetHealth<0.7);--心灵专注。
      ActBtnTurnRed(i,SkNm["驱散魔法"],false);--驱散魔法
      ActBtnTurnRed(i,SkNm["精神灼烧"],false);--精神灼烧
      ActBtnTurnRed(i,SkNm["虚空触须"],false);--虚空触须
      -- ActBtnTurnRed(i,SkNm["暗言术：灭"],true);--暗言术：灭
      ActBtnTurnRed(i,SkNm["束缚亡灵"],false);--束缚亡灵
      ActBtnTurnRed(i,SkNm["渐隐术"],playerIsTanking);--渐隐术
      ActBtnTurnRed(i,SkNm["绝望祷言"],playerHealth<0.5);--绝望祷言

      ActBtnTurnRed(i,SkNm["心灵之火"],not StringFindOr(playerAuraString,"心灵之火") and playerIsTanking);--心灵之火。
      ActBtnTurnRed(i,SkNm["心灵意志"],not StringFindOr(playerAuraString,"心灵意志") and not playerIsTanking);--心灵意志。
      ActBtnTurnRed(i,SkNm["防护恐惧结界"],not imMoving);--防护恐惧结界
      ActBtnTurnRed(i,SkNm["群体驱散"],false);--群体驱散
      ActBtnTurnRed(i,SkNm["惩击"],false);--惩击
      -- ActBtnTurnRed(i,SkNm["天使长"],true);--天使长
      ActBtnTurnRed(i,SkNm["真言术：韧"],not isEnemy and not StringFindOr(targetBuff,"真言术：韧"));--真言术：韧
      ActBtnTurnRed(i,SkNm["自利"],not HasFullControl()); --自利。
      ActBtnTurnRed(i,SkNm["射击"],not imMoving and IsAutoRepeatAction(i)==nil);--射击

   elseif(specialization=="战斗") then --盗贼战斗天赋。
      local combo_Points=GetComboPoints("player", "target");
      local plrThrStatus = UnitThreatSituation("player");
      local playerIsTanking = plrThrStatus~=nil and plrThrStatus>1
      local targetHealth=UnitHealth("target")/UnitHealthMax("target");

      ActBtnTurnRed(i,SkNm["脚踢"],targetIsChansting); --脚踢。
      ActBtnTurnRed(i,SkNm["凿击"],targetIsChansting); --凿击。
      ActBtnTurnRed(i,SkNm["切割"],not StringFindOr(playerAuraString,"切割")); --切割
      ActBtnTurnRed(i,SkNm["刺骨"],combo_Points==5 or combo_Points>=4 and StringFindAnd(debuffString,"要害打击") or targetHealth*10<=combo_Points); --刺骨
      ActBtnTurnRed(i,SkNm["影袭"],combo_Points<5 and StringFindAnd(debuffString,"要害打击")); --影袭
      ActBtnTurnRed(i,SkNm["要害打击"],combo_Points<5 and not StringFindAnd(debuffString,"要害打击")); --要害打击
      ActBtnTurnRed(i,SkNm["剑刃乱舞"],attackMode==1 and StringFindOr(playerAuraString,"剑刃乱舞") or attackMode==2 and not StringFindOr(playerAuraString,"剑刃乱舞")); --剑刃乱舞
      ActBtnTurnRed(i,SkNm["闪避"],playerIsTanking and playerHealth<0.5);--闪避。
      ActBtnTurnRed(i,SkNm["备战就绪"],playerIsTanking and playerHealth<0.65);--备战就绪。
      ActBtnTurnRed(i,SkNm["复原"],0.08*combo_Points<(1-playerHealth) and StringFindOr(playerAuraString,"复原")); --复原。
      ActBtnTurnRed(i,SkNm["消失"],playerIsTanking);--备战就绪。

   elseif(specialization=="野兽控制") then --猎人。
      local combo_Points=GetComboPoints("player", "target");
      local plrThrStatus = UnitThreatSituation("player");
      local playerIsTanking = plrThrStatus~=nil and plrThrStatus>1
      local targetHealth=UnitHealth("target")/UnitHealthMax("target");

     
      
   end
end 

function ActBtnTurnRed(i,j,condition)
   if(i==j and not condition) then actionButton_CDText[j]:SetTextColor(1,0,0) end;
end

function ActBtnTurnBlue(i,j)
   if(i==j) then actionButton_CDText[j]:SetTextColor(0,0,1) end;
end

function ActBtnTurnPink(i,j)
   if(i==j) then actionButton_CDText[j]:SetTextColor(1,0,1) end;
end

function WhoIsChansting(who)
   local spellName_Casting= UnitCastingInfo(who);
   local spellName_Channel= UnitChannelInfo(who);
   return spellName_Channel~=nil or spellName_Casting~=nil
end

function PartySelection()
   local partyMemberList={"player","party1","party2","party3","party4"};
   -- local partyMemberList={"player"};
   local MemberSelected="";  --声明最需要帮助的成员姓名。
   local trgNeedOfhelp=0;
   local mostInNeedOfHelp=0;

   for i,v in ipairs(partyMemberList) do --遍历所有Aura
      if(UnitIsDeadOrGhost(v)==1 or UnitHealthMax(v)==0 or not UnitInRange(v))then

      else
         local unitInjuried = 1-UnitHealth(v)/UnitHealthMax(v);
         local status = UnitThreatSituation(v);

         if(status==3 or status==2) then trgNeedOfhelp=unitInjuried*3 else trgNeedOfhelp=unitInjuried end;
         if(StringFindOr(UnitCleaning("戒律",v,"HARMFUL"),"Magic","Disease")) then trgNeedOfhelp=trgNeedOfhelp+0.15 end;

         if(trgNeedOfhelp>=mostInNeedOfHelp) then
            mostInNeedOfHelp=trgNeedOfhelp;
            MemberSelected=v;
         end
      end
   end

   return MemberSelected
end

function PaintPartyButton(slotID)
   local ptySlct=PartySelection();

   if(UnitCanAttack("player","target"))then
      actionButton_CDText[slotID]:SetTextColor(1,1,0);
   elseif(ptySlct=="player")then
      actionButton_CDText[slotID]:SetTextColor(0,0,1);
   elseif(ptySlct=="party1")then
      actionButton_CDText[slotID]:SetTextColor(0,1,0);
   elseif(ptySlct=="party2")then
      actionButton_CDText[slotID]:SetTextColor(0,1,1);
   elseif(ptySlct=="party3")then
      actionButton_CDText[slotID]:SetTextColor(1,0,0);
   elseif(ptySlct=="party4")then
      actionButton_CDText[slotID]:SetTextColor(1,0,1);
   else
      actionButton_CDText[slotID]:SetTextColor(1,1,0);
   end
end

function UnitCleaning(specialization,unit,filter)
   -- local unitAuraList={};    --声明UnitAura清单为空。
   local CleanClearString="";  --初始返回值targetDebuffString为空。
   
   for i=1,40 do
      local name, _, _, _, auraType = UnitAura(unit,i,filter);
      if(name==nil)then break end;
      
      if(auraType~=nil) then CleanClearString=CleanClearString..auraType end;
   end

   return CleanClearString
end